def split_dup_headers(headers):
    pass