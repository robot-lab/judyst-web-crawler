from ksrf import *
from web_crawler import *


def main():
    localStorage = LocalFileStorageSource()
    localStorage.prepare()
    webSource = KSRFWebSource(localStorage)
    headers = webSource.get_all_data(DataType.DOCUMENT_HEADER)
    print(headers)


main()
