# debug file for testing import
if __package__:
    from web_crawler.ksrf import *
else:
    from ksrf import *

somefun()
